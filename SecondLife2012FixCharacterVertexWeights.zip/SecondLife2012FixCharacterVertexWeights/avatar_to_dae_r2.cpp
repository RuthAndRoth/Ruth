#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

typedef signed char                     S8;
typedef unsigned char                   U8;
typedef signed short                    S16;
typedef unsigned short                  U16;
typedef signed int                      S32;
typedef unsigned int                    U32;

#ifndef TRUE
#define TRUE                    (1)
#endif

#ifndef FALSE
#define FALSE                   (0)
#endif

class Vector3
{
	public:
		float mV[3];

		inline void set(float x, float y, float z)
		{
			mV[0] = x;
			mV[1] = y;
			mV[2] = z;
		}
		inline void set(Vector3 *a)
		{
			mV[0] = a->mV[0];
			mV[1] = a->mV[1];
			mV[2] = a->mV[2];
		}
		inline void add(Vector3 *a)
		{
			mV[0] += a->mV[0];
			mV[1] += a->mV[1];
			mV[2] += a->mV[2];
		}
		inline void add(Vector3 *a, Vector3 *b)
		{
			mV[0] = a->mV[0] + b->mV[0];
			mV[1] = a->mV[1] + b->mV[1];
			mV[2] = a->mV[2] + b->mV[2];
		}
		inline void sub(Vector3 *a)
		{
			mV[0] -= a->mV[0];
			mV[1] -= a->mV[1];
			mV[2] -= a->mV[2];
		}
		inline void sub(Vector3 *a, Vector3 *b)
		{
			mV[0] = a->mV[0] - b->mV[0];
			mV[1] = a->mV[1] - b->mV[1];
			mV[2] = a->mV[2] - b->mV[2];
		}
		inline float mag2()
		{
			return (mV[0]*mV[0]) + (mV[1]*mV[1]) + (mV[2]*mV[2]);
		}
		inline float mag()
		{
			return sqrtf(mag2());
		}
};

class Vector2
{
	public:
		float mV[2];
};

#define HEADER_BINARY "Linden Binary Mesh 1.0"

class Joint
{
	private:
		Joint(const char *, Joint *, float, float, float);

		Joint *mParent;
		Joint *mChildren;
		Joint *mNext;

	public:
		const char *mName;
		Vector3 mPos;
		int mFlag;
		int mFlag2;

		Joint();

		Joint *find(const char *);

		void setup(Joint **, unsigned *);

		void save(FILE *);
};

Joint Root;

Joint::Joint()
{
	mName = 0;
	mParent = 0;
	mChildren = 0;
	mNext = 0;
	mPos.set(0.0, 0.0, 0.0);
	mFlag = 0;
	mFlag2 = 0;

	Joint *pelvis = new Joint("mPelvis", this, 0.000f, 0.000f, 1.067f);
	Joint *torso = new Joint("mTorso", pelvis, 0.000f, 0.000f, 0.084f);
	Joint *chest = new Joint("mChest", torso, -0.015f, 0.000f, 0.205f);
	Joint *neck = new Joint("mNeck", chest, -0.010f, 0.000f, 0.251f);
	Joint *head = new Joint("mHead", neck, 0.000f, 0.000f, 0.076f);
	Joint *skull = new Joint("mSkull", head, 0.000f, 0.000f, 0.079f);
	Joint *eyeright = new Joint("mEyeRight", head, 0.098f, -0.036f, 0.079f);
	Joint *eyeleft = new Joint("mEyeLeft", head, 0.098f, 0.036f, 0.079f);
	Joint *collarleft = new Joint("mCollarLeft", chest, -0.021f, 0.085f, 0.165f);
	Joint *shoulderleft = new Joint("mShoulderLeft", collarleft, 0.000f, 0.079f, 0.000f);
	Joint *elbowleft = new Joint("mElbowLeft", shoulderleft, 0.000f, 0.248f, 0.000f);
	Joint *wristleft = new Joint("mWristLeft", elbowleft, 0.000f, 0.205f, 0.000f);
	Joint *handleft = new Joint("mHandLeft", wristleft, 0.0f, 0.1f, 0.0f);
	Joint *collarright = new Joint("mCollarRight", chest, -0.021f, -0.085f, 0.165f);
	Joint *shoulderright = new Joint("mShoulderRight", collarright, 0.000f, -0.079f, 0.000f);
	Joint *elbowright = new Joint("mElbowRight", shoulderright, 0.000f, -0.248f, 0.000f);
	Joint *wristright = new Joint("mWristRight", elbowright, 0.000f, -0.205f, 0.000f);
	Joint *handright = new Joint("mHandRight", wristright, 0.0f, -0.1f, 0.0f);
	Joint *hipright = new Joint("mHipRight", pelvis, 0.034f, -0.128f, -0.041f);
	Joint *kneeright = new Joint("mKneeRight", hipright, -0.001f, 0.047f, -0.491f);
	Joint *ankleright = new Joint("mAnkleRight", kneeright, -0.029f, 0.000f, -0.468f);
	Joint *footright = new Joint("mFootRight", ankleright, 0.112f, 0.000f, -0.061f);
	Joint *toeright = new Joint("mToeRight", footright, 0.109f, 0.000f, 0.000f);
	Joint *hipleft = new Joint("mHipLeft", pelvis, 0.034f, 0.128f, -0.041f);
	Joint *kneeleft = new Joint("mKneeLeft", hipleft, -0.001f, -0.047f, -0.491f);
	Joint *ankleleft = new Joint("mAnkleLeft", kneeleft, -0.029f, 0.000f, -0.468f);
	Joint *footleft = new Joint("mFootLeft", ankleleft, 0.112f, 0.000f, -0.061f);
	Joint *toeleft = new Joint("mToeLeft", footleft, 0.109f, 0.000f, 0.000f);
}

Joint::Joint(const char *name, Joint *parent, float x, float y, float z)
{
	Joint **p = &parent->mChildren;
	while (Joint *j = *p) { p = &j->mNext; }
	*p = this;

	mName = name;
	mParent = parent;
	mChildren = 0;
	mNext = 0;
	mFlag = 0;
	mFlag2 = 0;

	mPos.set(x, y, z);
	mPos.add(&parent->mPos);
}

Joint *Joint::find(const char *name)
{
	for (Joint *j = mChildren; j; j = j->mNext)
	{
		if (!strcmp(j->mName, name))
			return j;
		Joint *c = j->find(name);
		if (c) return c;
	}
	return 0;
}

void Joint::setup(Joint **ptr, unsigned *idx)
{
	if (mFlag)
	{
		unsigned n = *idx;

		if (n < 1 || ptr[n - 1] != mParent)
		{
			ptr[n++] = mParent;
		}
		mFlag = n;
		ptr[n++] = this;

		*idx = n;
	}

	for (Joint *j = mChildren; j; j = j->mNext)
	{
		j->setup(ptr, idx);
	}
}

void Joint::save(FILE *fp)
{
	Vector3 vec;

	fprintf(fp, "<node id=\"%s\" sid=\"%s\" type=\"JOINT\">\n", mName, mName);
	vec.sub(&mPos, &mParent->mPos);
	fprintf(fp, "<translate>%.9g %.9g %.9g</translate>\n",
		vec.mV[0], vec.mV[1], vec.mV[2]);
	for (Joint *j = mChildren; j; j = j->mNext)
	{
		if (mFlag) j->save(fp);
	}
	fprintf(fp, "</node>\n");
}

typedef U16 Face[3];
typedef U32 Remap[2];

class Morph
{
	private:
		S32 mNumVertices;
		U32 *mVertexIndices;
		Vector3 *mCoords;
		Vector3 *mNormals;
		Vector3 *mBinormals;
		Vector2 *mTexCoords;

	public:
		const char *mName;
		Morph *mNext;

		Morph(const char *);
		~Morph();
		int load(FILE *, const char *);
};

Morph::Morph(const char *name)
{
	char *str = new char[strlen(name) + 1];
	strcpy(str, name);

	mName = str;
	mNext = 0;

	mCoords = 0;
	mNormals = 0;
	mBinormals = 0;
	mTexCoords = 0;
	mVertexIndices = 0;
}

Morph::~Morph()
{
	if (mNext) delete mNext;

	if (mName) delete [] mName;
	if (mVertexIndices) delete [] mVertexIndices;
	if (mCoords) delete [] mCoords;
	if (mNormals) delete [] mNormals;
	if (mBinormals) delete [] mBinormals;
	if (mTexCoords) delete [] mTexCoords;
}

int Morph::load(FILE *fp, const char *filename)
{
	if (fread(&mNumVertices, sizeof(S32), 1, fp) != 1)
	{
		fprintf(stderr, "%s: short read\n", filename);	
		return 1;
	}

	if (mVertexIndices) delete [] mVertexIndices;
	if (mCoords) delete [] mCoords;
	if (mNormals) delete [] mNormals;
	if (mBinormals) delete [] mBinormals;
	if (mTexCoords) delete [] mTexCoords;

        mVertexIndices = new U32[mNumVertices];
	mCoords = new Vector3[mNumVertices];
        mNormals = new Vector3[mNumVertices];
        mBinormals = new Vector3[mNumVertices];
        mTexCoords = new Vector2[mNumVertices];

	for(S32 v = 0; v < mNumVertices; v++)
	{
		if (fread(&mVertexIndices[v], sizeof(U32), 1, fp) != 1)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		if (mVertexIndices[v] >= 10000)
		{
			fprintf(stderr, "%s: bad morph index\n", filename);
			return 1;
		}

		if (fread(&mCoords[v].mV, sizeof(float), 3, fp) != 3)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		if (fread(&mNormals[v].mV, sizeof(float), 3, fp) != 3)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		if (fread(&mBinormals[v].mV, sizeof(float), 3, fp) != 3)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		if (fread(&mTexCoords[v].mV, sizeof(float), 2, fp) != 2)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}
	}

	return 0;
}

class Mesh
{
	private:
		U8 mIsLOD;
		U8 mHasWeights;
		U8 mHasDetailTexCoords;
		U8 mRotationOrder;
		U16 mNumVertices;
		U16 mNumFaces;
		U16 mNumSkinJoints;
		U32 mNumRemaps;
		Vector3 mPosition;
		Vector3 mRotationAngles;
		Vector3 mScale;
		Vector3 *mBaseCoords;
		Vector3 *mBaseNormals;
		Vector3 *mBaseBinormals;
		Vector2 *mTexCoords;
		Vector2 *mDetailTexCoords;
		float *mWeights;
		Face *mFaces;
		Joint **mJoints;
		Morph *mMorphs;
		Remap *mRemaps;

	public:
		Mesh();
		~Mesh();
		int load(const char *, U8);
		void setup();
		void save(const char *);
		int find(Vector3 *);
};

Mesh::Mesh()
{
	mBaseCoords = 0;
	mBaseNormals = 0;
	mBaseBinormals = 0;
	mTexCoords = 0;
	mDetailTexCoords = 0;
	mWeights = 0;
	mFaces = 0;
	mJoints = 0;
	mMorphs = 0;
	mRemaps = 0;
}

Mesh::~Mesh()
{
	if (mBaseCoords) delete [] mBaseCoords;
	if (mBaseNormals) delete [] mBaseNormals;
	if (mBaseBinormals) delete [] mBaseBinormals;
	if (mTexCoords) delete [] mTexCoords;
	if (mDetailTexCoords) delete [] mDetailTexCoords;
	if (mWeights) delete [] mWeights;
	if (mFaces) delete [] mFaces;
	if (mJoints) delete [] mJoints;
	if (mMorphs) delete mMorphs;
	if (mRemaps) delete [] mRemaps;
}

int Mesh::load(const char *filename, U8 isLOD)
{
	FILE *fp = fopen(filename, "rb");
	if (!fp)
	{
		perror(filename);
		return 1;
	}

	char header[128];
	if (fread(header, sizeof(char), 128, fp) != 128)
	{
		fprintf(stderr, "%s: short read\n", filename);
		return 1;
	}

	if (strncmp(header, HEADER_BINARY, strlen(HEADER_BINARY)) != 0)
	{
		fprintf(stderr, "%s: invalid mesh file header\n", filename);
		return 1;
	}

	if (mBaseCoords) delete [] mBaseCoords;
	if (mBaseNormals) delete [] mBaseNormals;
	if (mBaseBinormals) delete [] mBaseBinormals;
	if (mTexCoords) delete [] mTexCoords;
	if (mDetailTexCoords) delete [] mDetailTexCoords;
	if (mFaces) delete [] mFaces;
	if (mJoints) delete [] mJoints;
	if (mMorphs) delete mMorphs;
	if (mRemaps) delete []  mRemaps;

	mBaseCoords = 0;
	mBaseNormals = 0;
	mBaseBinormals = 0;
	mTexCoords = 0;
	mDetailTexCoords = 0;
	mFaces = 0;
	mJoints = 0;
	mMorphs = 0;
	mRemaps = 0;

	mIsLOD = isLOD;

	fprintf(stderr, "Loading: %s\n", filename);

	fseek(fp, 24, SEEK_SET);

	if (fread(&mHasWeights, sizeof(U8), 1, fp) != 1)
	{
		fprintf(stderr, "%s: short read\n", filename);	
		return 1;
	}

	if (fread(&mHasDetailTexCoords, sizeof(U8), 1, fp) != 1)
	{
		fprintf(stderr, "%s: short read\n", filename);	
		return 1;
	}

	if (fread(mPosition.mV, sizeof(float), 3, fp) != 3)
	{
		fprintf(stderr, "%s: short read\n", filename);	
		return 1;
	}

	if (fread(mRotationAngles.mV, sizeof(float), 3, fp) != 3)
	{
		fprintf(stderr, "%s: short read\n", filename);	
		return 1;
	}

	if (fread(&mRotationOrder, sizeof(U8), 1, fp) != 1)
	{
		fprintf(stderr, "%s: short read\n", filename);	
		return 1;
	}

	if (fread(mScale.mV, sizeof(float), 3, fp) != 3)
	{
		fprintf(stderr, "%s: short read\n", filename);	
		return 1;
	}

	mNumVertices = 0;

	if (isLOD)
	{
		if (fread(&mNumVertices, sizeof(U16), 1, fp) != 1)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		mBaseCoords = new Vector3[mNumVertices];

		if (fread(mBaseCoords, 3*sizeof(float), mNumVertices, fp) != mNumVertices)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		mBaseNormals = new Vector3[mNumVertices];

		if (fread(mBaseNormals, 3*sizeof(float), mNumVertices, fp) != mNumVertices)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		mBaseBinormals = new Vector3[mNumVertices];

		if (fread(mBaseBinormals, 3*sizeof(float), mNumVertices, fp) != mNumVertices)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		mTexCoords = new Vector2[mNumVertices];

		if (fread(mTexCoords, 2*sizeof(float), mNumVertices, fp) != mNumVertices)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		if (mHasDetailTexCoords)
		{
			mDetailTexCoords = new Vector2[mNumVertices];

			if (fread(mDetailTexCoords, 2*sizeof(float), mNumVertices, fp) != mNumVertices)
			{
				fprintf(stderr, "%s: short read\n", filename);	
				return 1;
			}
		}

		if (mHasWeights)
		{
			mWeights = new float[mNumVertices];

			if (fread(mWeights, sizeof(float), mNumVertices, fp) != mNumVertices)
			{
				fprintf(stderr, "%s: short read\n", filename);	
				return 1;
			}
		}
	}

	if (fread(&mNumFaces, sizeof(U16), 1, fp) != 1)
	{
		fprintf(stderr, "%s: short read\n", filename);	
		return 1;
	}

	mFaces = new Face[mNumFaces];

	for (U32 i = 0; i < mNumFaces; i++)
	{
		if (fread(mFaces[i], sizeof(U16), 3, fp) != 3)
		{
			fprintf(stderr, "%s: short read\n", filename);	
			return 1;
		}

		if (isLOD)
		{
			for (U32 j = 0; j < 3; j++)
			{
				if (mFaces[i][j] > mNumVertices - 1)
				{
					fprintf(stderr, "%s: not enough vertices\n", filename);	
					return 1;
				}
			}
		}
	}

	mNumSkinJoints = 0;
		
	if (isLOD)
	{
		if (mHasWeights)
		{
			if (fread(&mNumSkinJoints, sizeof(U16), 1, fp) != 1)
			{
				fprintf(stderr, "%s: short read\n", filename);	
				return 1;
			}
		}

		mJoints = new Joint *[mNumSkinJoints];

		for (U32 i = 0; i < mNumSkinJoints; i++)
		{
			char jointName[64+1];
			if (fread(jointName, sizeof(jointName)-1, 1, fp) != 1)
			{
				fprintf(stderr, "%s: short read\n", filename);	
				return 1;
			}
			jointName[sizeof(jointName)-1] = '\0'; // ensure nul-termination
			mJoints[i] = Root.find(jointName);
			mJoints[i]->mFlag = 1;
			mJoints[i]->mFlag2 = i;
		}

		Morph **morphPtr = &mMorphs;

		char morphName[64+1];
		morphName[sizeof(morphName)-1] = '\0'; // ensure nul-termination
		while(fread(&morphName, sizeof(char), 64, fp) == 64)
		{
			if (!strcmp(morphName, "End Morphs"))
			{
				break;
			}

			Morph *morph = new Morph(morphName);
			*morphPtr = morph;
			morphPtr = &morph->mNext;

			morph->load(fp, filename);
		}

		if (fread(&mNumRemaps, sizeof(U32), 1, fp) == 1)
		{
			if (mNumRemaps)
			{
				mRemaps = new Remap[mNumRemaps];
				
				if (fread(mRemaps, sizeof(Remap), mNumRemaps, fp) != mNumRemaps)
				{
					fprintf(stderr, "%s: short read\n", filename);	
					return 1;
				}
			}
		}
	}

	fclose(fp);
	return 0;
}

Joint *joints[34];

void Mesh::setup()
{
	if (mHasWeights)
	{
		unsigned n = 0;
		Root.setup(joints, &n);
	}
}

int Mesh::find(Vector3 *vec)
{
	int i0 = -1;
	float d0 = FLT_MAX;

	for (int i = 0; i < mNumVertices; ++i)
	{
		Vector3 v;
		v.sub(vec, &mBaseCoords[i]);
		float d = v.mag2();

		if (d < d0)
		{
			i0 = i;
			d0 = d;
		}
	}

	return i0;
}

void Mesh::save(const char *name)
{
	char buffer[1024];
	U32 i, j;

	sprintf(buffer, "%s.dae", name);
	FILE *fp = fopen(buffer, "w");
	if (!fp)
	{
		perror(buffer);
		return;
	}

	fprintf(stderr, "Saveing %s\n", buffer);

	fprintf(fp, "<?xml version=\"1.0\"?>\n");
	fprintf(fp, "<COLLADA xmlns=\"http://www.collada.org/2008/03/COLLADASchema\" version=\"1.5.0\">\n");

	fprintf(fp, "<asset>\n");
	fprintf(fp, "<created/>\n");
	fprintf(fp, "<modified/>\n");
	fprintf(fp, "</asset>\n");

	fprintf(fp, "<library_geometries>\n");
	fprintf(fp, "<geometry id=\"mesh\">\n");
	fprintf(fp, "<mesh>\n");

	fprintf(fp, "<source id=\"positions\">\n");
	fprintf(fp, "<float_array id=\"position-array\" count=\"%d\">\n", mNumVertices * 3);
	for (i = 0; i < mNumVertices; i++)
	{
		fprintf(fp, "%.9g %.9g %.9g\n",
			mBaseCoords[i].mV[0],
			mBaseCoords[i].mV[1],
			mBaseCoords[i].mV[2]);
	}
	fprintf(fp, "</float_array>\n");
	fprintf(fp, "<technique_common>\n");
	fprintf(fp, "<accessor source=\"#position-array\" count=\"%d\" stride=\"3\">\n", mNumVertices);
	fprintf(fp, "<param name=\"X\" type=\"float\"/>\n");
	fprintf(fp, "<param name=\"Y\" type=\"float\"/>\n");
	fprintf(fp, "<param name=\"Z\" type=\"float\"/>\n");
	fprintf(fp, "</accessor>\n");
	fprintf(fp, "</technique_common>\n");
	fprintf(fp, "</source>\n");

	fprintf(fp, "<source id=\"normals\">\n");
	fprintf(fp, "<float_array id=\"normal-array\" count=\"%d\">\n", mNumVertices * 3);
	for (i = 0; i < mNumVertices; i++)
	{
		fprintf(fp, "%.9g %.9g %.9g\n",
			mBaseNormals[i].mV[0],
			mBaseNormals[i].mV[1],
			mBaseNormals[i].mV[2]);
	}
	fprintf(fp, "</float_array>\n");
	fprintf(fp, "<technique_common>\n");
	fprintf(fp, "<accessor source=\"#normal-array\" count=\"%d\" stride=\"3\">\n", mNumVertices);
	fprintf(fp, "<param name=\"X\" type=\"float\"/>\n");
	fprintf(fp, "<param name=\"Y\" type=\"float\"/>\n");
	fprintf(fp, "<param name=\"Z\" type=\"float\"/>\n");
	fprintf(fp, "</accessor>\n");
	fprintf(fp, "</technique_common>\n");
	fprintf(fp, "</source>\n");

	fprintf(fp, "<source id=\"texcoords\">\n");
	fprintf(fp, "<float_array id=\"texcoord-array\" count=\"%d\">\n", mNumVertices * 2);
	for (i = 0; i < mNumVertices; i++)
	{
		fprintf(fp, "%.9g %.9g\n",
			mTexCoords[i].mV[0],
			mTexCoords[i].mV[1]);
	}
	fprintf(fp, "</float_array>\n");
	fprintf(fp, "<technique_common>\n");
	fprintf(fp, "<accessor source=\"#texcoord-array\" count=\"%d\" stride=\"2\">\n", mNumVertices);
	fprintf(fp, "<param name=\"U\" type=\"float\"/>\n");
	fprintf(fp, "<param name=\"V\" type=\"float\"/>\n");
	fprintf(fp, "</accessor>\n");
	fprintf(fp, "</technique_common>\n");
	fprintf(fp, "</source>\n");

	fprintf(fp, "<vertices id=\"vertices\">\n");
	fprintf(fp, "<input semantic=\"POSITION\" source=\"#positions\"/>\n");
	fprintf(fp, "</vertices>\n");

	fprintf(fp, "<triangles count=\"%d\">\n", mNumFaces);
	fprintf(fp, "<input semantic=\"VERTEX\" source=\"#vertices\" offset=\"0\"/>\n");
	fprintf(fp, "<input semantic=\"NORMAL\" source=\"#normals\" offset=\"0\"/>\n");
	fprintf(fp, "<input semantic=\"TEXCOORD\" source=\"#texcoords\" offset=\"0\"/>\n");
	fprintf(fp, "<p>\n");
	for (i = 0; i < mNumFaces; i++)
	{
		fprintf(fp, "%d %d %d\n", mFaces[i][0], mFaces[i][1], mFaces[i][2]);
	}
	fprintf(fp, "</p>\n");
	fprintf(fp, "</triangles>\n");

	fprintf(fp, "</mesh>\n");
	fprintf(fp, "</geometry>\n");
	fprintf(fp, "</library_geometries>\n");

	if (mHasWeights)
	{
		fprintf(fp, "<library_controllers>\n");
		fprintf(fp, "<controller id=\"skin\">\n");
		fprintf(fp, "<skin source=\"#mesh\">\n");

		fprintf(fp, "<source id=\"joints\">\n");
		fprintf(fp, "<Name_array id=\"joint-array\" count=\"%d\">\n", mNumSkinJoints);
		for (i = 0; i < mNumSkinJoints; ++i)
		{
			fprintf(fp, "%s\n", mJoints[i]->mName);
		}
		fprintf(fp, "</Name_array>\n");
		fprintf(fp, "<technique_common>\n");
		fprintf(fp, "<accessor source=\"#joint-array\" count=\"%d\" stride=\"1\">\n", mNumSkinJoints);
		fprintf(fp, "<param name=\"JOINT\" type=\"name\"/>\n");
		fprintf(fp, "</accessor>\n");
		fprintf(fp, "</technique_common>\n");
		fprintf(fp, "</source>\n");

		fprintf(fp, "<source id=\"weights\">\n");
		for (i = j = 0; i < mNumVertices; i++)
		{
			float f = mWeights[i];
			j += (f == floorf(f)) ? 1 : 2;
		}
		fprintf(fp, "<float_array id=\"weight-array\" count=\"%d\">\n", j);
		for (i = 0; i < mNumVertices; i++)
		{
			float w = mWeights[i];
			float f = floorf(w);
			if (f == w)
			{
				fprintf(fp, "1.0\n");
			}
			else
			{
				w -= f;
				fprintf(fp, "%.9g %.9g\n", 1.0 - w, w);
			}
		}
		fprintf(fp, "</float_array>\n");
		fprintf(fp, "<technique_common>\n");
		fprintf(fp, "<accessor source=\"#weight-array\" count=\"%d\" stride=\"1\">\n", j);
		fprintf(fp, "<param name=\"WEIGHT\" type=\"float\"/>\n");
		fprintf(fp, "</accessor>\n");
		fprintf(fp, "</technique_common>\n");
		fprintf(fp, "</source>\n");

		fprintf(fp, "<source id=\"inv-bind\">\n");
		fprintf(fp, " <float_array id=\"inv-bind-array\" count=\"%d\">\n", mNumSkinJoints * 16);
		for (i = 0; i < mNumSkinJoints; ++i)
		{
			fprintf(fp, "1.0 0.0 0.0 %.9f  0.0 1.0 0.0 %.9f  0.0 0.0 1.0 %.9f  0.0 0.0 0.0 1.0\n",
				-mJoints[i]->mPos.mV[0], -mJoints[i]->mPos.mV[1], -mJoints[i]->mPos.mV[2]);
		}
		fprintf(fp, "</float_array>\n");
		fprintf(fp, "<technique_common>\n");
		fprintf(fp, "<accessor source=\"#inv-bind-array\" count=\"%d\" stride=\"16\">\n", mNumSkinJoints);
		fprintf(fp, "<param name=\"TRANSFORM\" type=\"float4x4\"/>\n");
		fprintf(fp, "</accessor>\n");
		fprintf(fp, "</technique_common>\n");
		fprintf(fp, "</source>\n");

		fprintf(fp, "<joints>\n");
		fprintf(fp, "<input semantic=\"JOINT\" source=\"#joints\"/>\n");
		fprintf(fp, "<input semantic=\"INV_BIND_MATRIX\" source=\"#inv-bind\"/>\n");
		fprintf(fp, "</joints>\n");

		fprintf(fp, "<vertex_weights count=\"%d\">\n", mNumVertices);
		fprintf(fp, "<input semantic=\"JOINT\" source=\"#joints\" offset=\"0\"/>\n");
		fprintf(fp, "<input semantic=\"WEIGHT\" source=\"#weights\" offset=\"1\"/>\n");
		fprintf(fp, "<vcount>\n");
		for (i = 0; i < mNumVertices; i++)
		{
			float f = mWeights[i];
			fprintf(fp, f == floorf(f) ? "1\n" : "2\n");
		}
		fprintf(fp, "</vcount>\n");
		fprintf(fp, "<v>\n");
		for (i = j = 0; i < mNumVertices; i++)
		{
			float w = mWeights[i];
			float f = floorf(w);
			Joint *j1 = joints[int(f)];
			Joint *j2 = joints[int(f) + 1];
		
			if(w == f)
			{
				fprintf(fp, "%d %d\n", j1->mFlag2, j++);
			}
			else
			{
				fprintf(fp, "%d %d  %d %d\n", j1->mFlag2, j, j2->mFlag2, j + 1);
				j += 2;
			}
		}
		fprintf(fp, "</v>\n");
		fprintf(fp, "</vertex_weights>\n");

		fprintf(fp, "</skin>\n");
		fprintf(fp, "</controller>\n");
		fprintf(fp, "</library_controllers>\n");

		fprintf(fp, "<library_visual_scenes>\n");
		fprintf(fp, "<visual_scene id=\"scene\">\n");

		fprintf(fp, "<node>\n");
		fprintf(fp, "<translate>%.9g %.9g %.9g</translate>\n",
			joints[0]->mPos.mV[0], joints[0]->mPos.mV[1], joints[0]->mPos.mV[2]);
		joints[1]->save(fp);
		fprintf(fp, "</node>\n");

		fprintf(fp, "<node>\n");
		fprintf(fp, "<instance_controller url=\"#skin\">\n");
		fprintf(fp, "<skeleton>#%s</skeleton>\n", joints[1]->mName);
		fprintf(fp, "</instance_controller>\n");
		fprintf(fp, "</node>\n");

		fprintf(fp, "</visual_scene>\n");
		fprintf(fp, "</library_visual_scenes>\n");
	}
	else
	{
		fprintf(fp, "<library_visual_scenes>\n");
		fprintf(fp, "<visual_scene id=\"scene\">\n");

		fprintf(fp, "<node>\n");
		fprintf(fp, "<instance_geometry url=\"#mesh\"/>\n");
		fprintf(fp, "</node>\n");

		fprintf(fp, "</visual_scene>\n");
		fprintf(fp, "</library_visual_scenes>\n");
	}

	fprintf(fp, "<scene>\n");
	fprintf(fp, "<instance_visual_scene url=\"#scene\"/>\n");
	fprintf(fp, "</scene>\n");

	fprintf(fp, "</COLLADA>\n");

	fclose(fp);
}

int main(int argc, char **argv)
{
	Mesh mesh;

	if (argc != 2)
	{
		fprintf(stderr, "Usage: %s LOD0\n", argv[0]);
		return 1;
	}

	if (mesh.load(argv[1], 1))
	{
		return 1;
	}
	mesh.setup();
	mesh.save(argv[1]);

	return 0;
}
